import React, { useState } from 'react';

const AnimalZooWidget = () => {
  const [animals, setAnimals] = useState([]);
  const [newAnimalName, setNewAnimalName] = useState('');
  const [newAnimalLifespan, setNewAnimalLifespan] = useState('');

  const addAnimal = () => {
    const newAnimal = {
      name: newAnimalName,
      lifespan: newAnimalLifespan
    };
    setAnimals([...animals, newAnimal]);
    setNewAnimalName('');
    setNewAnimalLifespan('');
  };

  const deleteAnimal = (index) => {
    const updatedAnimals = [...animals];
    updatedAnimals.splice(index, 1);
    setAnimals(updatedAnimals);
  };

  const updateAnimal = (index, updatedAnimalName, updatedAnimalLifespan) => {
    const updatedAnimals = [...animals];
    updatedAnimals[index] = {
      name: updatedAnimalName,
      lifespan: updatedAnimalLifespan
    };
    setAnimals(updatedAnimals);
  };

  return (
    <div>
      <h2>Animal-Zoo</h2>
      <ul>
        {animals.map((animal, index) => (
          <li key={index}>
            <span>{animal.name} (Lifespan: {animal.lifespan})</span>
            <button onClick={() => deleteAnimal(index)}>Delete</button>
          </li>
        ))}
      </ul>

      <h3>Add New Animal</h3>
      <input
        type="text"
        placeholder="Animal Name"
        value={newAnimalName}
        onChange={(e) => setNewAnimalName(e.target.value)}
      />
      <input
        type="text"
        placeholder="Lifespan"
        value={newAnimalLifespan}
        onChange={(e) => setNewAnimalLifespan(e.target.value)}
      />
      <button onClick={addAnimal}>Add Animal</button>
    </div>
  );
};

export default AnimalZooWidget;
